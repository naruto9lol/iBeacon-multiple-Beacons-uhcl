//
//  ViewController.swift
//  closest-beacon-demo
//
//
import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate
{
    @IBOutlet weak var RssLabel: UILabel!
    
    @IBOutlet weak var DistanceLabel: UILabel!
    
    
    
    @IBOutlet weak var Rss2Label: UILabel!
    
    @IBOutlet weak var Distance2Label: UILabel!
    
    
    
    @IBOutlet weak var Rss3Label: UILabel!
    
    @IBOutlet weak var Distance3Label: UILabel!
    
    
    
    @IBOutlet weak var BColor1: UILabel!
    
    
    @IBOutlet weak var BColor2: UILabel!
    
    @IBOutlet weak var BColor3: UILabel!
    //rss value closer to zero better
    var rss = 1
    //distance from beacon to user phone
    var distance: Double = 1
    
    var identifier1 = 1
    
    //
    //rss value closer to zero better
    var rss2 = 1
    //distance from beacon to user phone
    var distance2: Double = 1
    
    var identifier2 = 1    //
    
    
    
    //rss value closer to zero better
    var rss3 = 1
    //distance from beacon to user phone
    var distance3: Double = 1
    
    var identifier3 = 1
    
    let locationManager = CLLocationManager()
    let region = CLBeaconRegion(proximityUUID: UUID(uuidString: "B9407F30-F5F8-466E-AFF9-25556B57FE6D")!, identifier: "DeltaBeacons")
    // Note: make sure you replace the keys here with your own beacons' Minor Values
    let colors = [
        32449: UIColor(red: 84/255, green: 77/255, blue: 160/255, alpha: 1),
        25307 :UIColor(red: 142/255, green: 212/255, blue: 220/255, alpha: 1),
        47874: UIColor(red: 162/255, green: 213/255, blue: 181/255, alpha: 1)
    ]

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.authorizedWhenInUse)
        {
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.startRangingBeacons(in: region)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion)
    {
        
        print(beacons)
        print("\n")
        
        
        
        let knownBeacons = beacons.filter{ $0.proximity != CLProximity.unknown
            
        }
        
        //> 0 is for one beacon in rane, 1 for two and so on
        if (knownBeacons.count > 2)
        {
           let closestBeacon = knownBeacons[0] as CLBeacon
            //
        
        
            let secondClosestBeacon = knownBeacons[1] as CLBeacon
            
            
            let thirdClosestBeacon = knownBeacons[2] as CLBeacon
            
            
            self.view.backgroundColor = self.colors[closestBeacon.minor.intValue]
            
             rss = closestBeacon.rssi
            distance = closestBeacon.accuracy
            identifier1 = Int(closestBeacon.minor)
            
            //
            rss2 = secondClosestBeacon.rssi
            distance2 = secondClosestBeacon.accuracy
            identifier2 = Int(secondClosestBeacon.minor)
            
            
            
            rss3 = thirdClosestBeacon.rssi
            distance3 = thirdClosestBeacon.accuracy
            identifier3 = Int(thirdClosestBeacon.minor)
            
            print("RSS: ",rss)
            print("\n")
            print("Meters: ", distance)
            
            
            //
            print("RSS: ",rss2)
            print("\n")
            print("Meters: ", distance2)
            
            
            
            //
            print("RSS: ",rss3)
            print("\n")
            print("Meters: ", distance3)
            
            
            var rssString = String(rss)
            var distanceString = String(distance)
            var identifierString = String(identifier1)
            
            
            
            //
            var rssString2 = String(rss2)
            var distanceString2 = String(distance2)
            var identifierString2 = String(identifier2)
            //
            var rssString3 = String(rss3)
            var distanceString3 = String(distance3)
            var identifierString3 = String(identifier3)
            
            
            
            self.RssLabel.text = rssString
            self.DistanceLabel.text = distanceString
            self.BColor1.text = identifierString
            
            
            self.Rss2Label.text = rssString2
            self.Distance2Label.text = distanceString2
            self.BColor2.text = identifierString2
            
            
            
            self.Rss3Label.text = rssString3
            self.Distance3Label.text = distanceString3
            self.BColor3.text = identifierString3
            
            
        }
    }
    
    /*
    @IBAction func showAlert(_ sender: Any)
    
    {
        func showAlert(title: String, message: String)
        {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
            let OKAction = UIAlertAction(title: "OK", style: .default)
            alertController.addAction(OKAction)
            
            var alertWindow : UIWindow!
            alertWindow = UIWindow.init(frame: UIScreen.main.bounds)
            alertWindow.rootViewController = UIViewController.init()
            alertWindow.windowLevel = UIWindowLevelAlert + 1
            alertWindow.makeKeyAndVisible()
            alertWindow.rootViewController?.present(alertController, animated: true)
        }
        
        
        var myString = String(rss)
        var distanceString = String(distance)
        
        showAlert(title: "RSSA: ", message: myString)
        showAlert(title: "Meters", message: distanceString)
        //let alert = UIAlertController(title: "RSS", message: ".", preferredStyle: .alert)
       // alert.addAction(UIAlertAction(title: "OK", style: .default, handler: )
    }
    
    
    //@IBAction func rds(_ sender: UIButton)
    //{
       // print(rss)
        
    //}
    
   */
 }
 
 
