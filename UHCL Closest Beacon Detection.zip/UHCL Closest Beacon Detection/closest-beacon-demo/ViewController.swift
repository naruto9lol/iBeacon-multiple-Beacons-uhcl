
/*
File Name: ViewController.swift
Author: Jhonatan Ramirez
Last Modification Date: April 14, 2018
 About: Detects the closest beacon in range.
 Can detect unlimited beacons but returns the closest to the user.
*/
 
 
//Second version prototype
import UIKit
import CoreLocation



class ViewController: UIViewController, CLLocationManagerDelegate
{
    
   
    @IBOutlet weak var message: UIImageView!
    
    //rss value closer to zero better
    var rss = 0
    //distance from beacon to user phone
    var distance: Double = 0
    //minor value
    var minorIdentifier = 0
    
    
    
    //minor value of beacon
    var FloorOneRightEntrance: Int  = 32449
    
    
    
    let locationManager = CLLocationManager()
    //UUID of beacon's
    let region = CLBeaconRegion(proximityUUID: UUID(uuidString: "B9407F30-F5F8-466E-AFF9-25556B57FE6D")!, identifier: "DeltaBeacons")
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.authorizedWhenInUse)
        {
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.startRangingBeacons(in: region)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion)
    {
        
        /*console
        print(beacons)
        print("\n")
        */
        
        //filters(ignors) error when proximity is zero
        let knownBeacons = beacons.filter{ $0.proximity != CLProximity.unknown
            
        }
        
        
        //if no beacons are in range
        message.image = UIImage(named:"outOfRange.png")
        
        //one close beacon
        //> 0 is for one beacon in range, 1 for two and so on
        if (knownBeacons.count > 0)
        {
            //array that contains beacon details
            let closestBeacon = knownBeacons[0] as CLBeacon
            
            
            //grabs values from array
            rss = closestBeacon.rssi
            distance = closestBeacon.accuracy
            minorIdentifier = Int(truncating: closestBeacon.minor)
            
            
            
            /*console
            print("RSS: ",rss)
            print("\n")
            print("Meters: ", distance)
             */
            
            
            //first message to user
        if( minorIdentifier == FloorOneRightEntrance && distance >= 2.0 && distance <= 3.0)
                {
               
                message.image = UIImage(named:"rightDirection.png")
                
                }
            
            
            //arrow foward
            if( minorIdentifier == FloorOneRightEntrance && distance >= 1.0 && distance <= 1.99)
            {
                
                message.image = UIImage(named:"frontDirection.png")
                
            }
            
            //when user is close to x notify
            if( minorIdentifier == FloorOneRightEntrance && distance <= 0.99)
            {
               
                
                message.image = UIImage(named:"succesArea.png")
                
            }
            
            
            
            
        }
        
        
        
 
 }
}
 

